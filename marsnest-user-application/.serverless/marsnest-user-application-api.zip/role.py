import enum

# Using enum class create enumerations
class Role(enum.Enum):
  visitor = 1
  admin = 2